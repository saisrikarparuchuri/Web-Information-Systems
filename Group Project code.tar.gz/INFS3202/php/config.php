<?php
    $link = mysqli_connect('localhost','arunharish','ArunKenSai@2017');
    mysqli_select_db($link,'studenttm1.2');
?>    